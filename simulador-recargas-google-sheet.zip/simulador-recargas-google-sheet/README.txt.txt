﻿INSTRUCCIONES PARA USAR EL SIMULADOR DE RECARGAS CON GOOGLE SHEET

1. Abre tu Google Sheet
2. Ve a "Archivo > Publicar en la web"
3. Selecciona formato CSV y haz clic en "Publicar"
4. Copia la URL y reemplázala en:
   - panel-admin/script.js → sheetURL

5. En Google Apps Script, publica tu Web App
6. Copia la URL y reemplázala en:
   - simulador/script.js → fetch("AQUÍ")

7. ¡Listo! Ahora puedes abrir el sitio localmente o subirlo online.